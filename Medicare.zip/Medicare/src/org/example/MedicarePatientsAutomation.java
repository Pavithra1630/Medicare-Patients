package org.example:

import io.github.bonigarcia.wdm.WebDriverManager;

import org.junit.Assert;

import org.openqa.selenium.*;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.chrome.ChromeOptions;

import org.openqa.selenium.interactions.Actions:

import java.util.List;

public class MedicarePatientsAutomation{

public static void main(String[] args) {

WebDriverManager.chromedriver().setup();

ChromeOptions options =new Chromeoptions();

WebDriver driver =new ChromeDriver(options);


try {

driver.manage().window().maximize();

driver.get("https://fitpeo.com/revenue-calculator");

WebElement slider driver.findElement(By.xpath(xpattiExpression: *//span[contains(@class, 'Ruislider-track")]/following-sibling::span"));

WebElement sliderInput slider.findElement(By.tagName("input"));

int min Integer.parseInt(sliderInput.getAttribute(name: "min"));

int nax Integer.parseInt(sliderInput.getAttribute(name: "max"));

int currentValue Integer.parseInt(slider Input.getAttribute(name: "value"));

int step Integer.parseInt(sliderInput.getAttribute(name: "step"));

int targetValue = 820;

// Move the slider to the target value

while (currentValue < targetValue) { 
	sliderInput.sendKeys(Keys.ARROW_RIGHT);
currentValue Integer.parseInt(sliderInput.getAttribute(name: "value"));
}


WebElement input-driver.findElement(By.xpath( xpathExpression: //div[contains(@class,'MuiBox-root')]//div/input));

Assert.assertEquals(Integer.parseInt(input.getAttribute(name: "value")), targetValue);

//input.click();

clearField(input, String.valueOf(targetValue));

input.sendKeys(keysToSend: "560");

Assert.assertEquals(Integer.parseInt(sliderInput.getAttribute(name: "value")), actual: 560);

clearField(input, Input: "560");

input.sendKeys(keysToSend: String.valueOf(targetValue);

List<String> cptCodes =List.of("CPT-99091", "CPT-99453", "CPT-99454", "CPT-99474");

for (String cptCode: cptCodes) {

WebElement checkbox = driver.findElement(By.xpath(xpath Expression: "//p[contains(text(), "+cptCode+")]/following-sibling::label//input*));

if (!checkbox.isSelected()) {


checkbox.click();


}
}
Assert.assertEquals(driver.findElement(By.xpath(xpathExpression: "//p[contains(text(), 'Total Recurring Reimbursement for all Patients Per Month: ')1/p*)).getText(), actual "$110708");

} catch (NoSuchElementException e) {


System.err.println("Error: Element not found" +e.getMessage());

} catch (WebDriverException e) {

System.err.println("WebDriver error"+e.getMessage());

} catch (Exception e) {

System.err.println("An unexpected error occurred"+e.getMessage());

} finally {

driver.quit();


}
}

2 usages

public static void clearfield(WebElement field, String input){

field.click();

for(int 10; 1 <input.length() + 1; 1++){
	field.sendKeys(Keys.BACK_SPACE);
}

}

}
